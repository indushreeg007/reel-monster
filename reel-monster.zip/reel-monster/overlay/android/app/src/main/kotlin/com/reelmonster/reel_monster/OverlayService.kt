package com.reelmonster.reel_monster
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import androidx.core.content.ContextCompat

class OverlayService : Service() {
  private lateinit var wm: WindowManager; private lateinit var v: MonsterView; private lateinit var lp: WindowManager.LayoutParams
  private val h = Handler(Looper.getMainLooper()); private var lastSpoken = ""; private var lastLevel = 0; private var lastTotal = -1
  private var lastChange = System.currentTimeMillis(); private var shocked = false
  private val scales = floatArrayOf(.45f, .55f, .7f, .8f, .9f, 1f)
  private val rec = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) = refresh() }
  private val pools = mapOf(
    1 to listOf("Just one more? Okay!", "We're having a productive day!"),
    2 to listOf("Again? Seriously?", "Your thumb deserves a holiday."),
    3 to listOf("Are we getting paid for this?", "I think we live here now."),
    4 to listOf("PLEASE TOUCH GRASS!", "Your responsibilities are crying.", "Even I need a break!"),
    5 to listOf("I have seen 150 reels. I need therapy.", "Your future self is disappointed."),
    6 to listOf("WE ARE NEVER LEAVING THIS APP!", "I WAS BORN TO BE A MONSTER, NOT A SCROLLING MACHINE!", "PLEASE CLOSE INSTAGRAM!"))
  private val clear = Runnable { v.speech = null; v.invalidate() }

  override fun onCreate() {
    super.onCreate()
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("rm", "Reel Monster", NotificationManager.IMPORTANCE_MIN))
    val n = Notification.Builder(this, "rm").setContentTitle("Reel Monster is floating 👾").setSmallIcon(android.R.drawable.ic_menu_view).build()
    if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    wm = getSystemService(WINDOW_SERVICE) as WindowManager
    val sp = getSharedPreferences("rm", 0); val d = resources.displayMetrics.density
    v = MonsterView(this)
    lp = WindowManager.LayoutParams((200 * d).toInt(), (290 * d).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
      PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = sp.getInt("x", 40); y = sp.getInt("y", 300) }
    var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
    v.setOnTouchListener { _, e ->
      when (e.action) {
        MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
        MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - dx) + Math.abs(e.rawY - dy) > 12) moved = true
          if (moved) { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(v, lp) } }
        MotionEvent.ACTION_UP -> if (moved) sp.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
          else if (v.hitsButton(e.x, e.y)) { v.minimized = !v.minimized; v.invalidate() } else tap()
      }; true }
    wm.addView(v, lp)
    ContextCompat.registerReceiver(this, rec, IntentFilter("com.reelmonster.UPDATE"), ContextCompat.RECEIVER_NOT_EXPORTED)
    refresh(); sleepCheck()
  }

  private fun exFor(l: Int) = when (l) { 1, 2 -> MonsterView.Ex.HAPPY; 3 -> MonsterView.Ex.EXCITED; 4 -> MonsterView.Ex.OVERWHELMED; 5 -> MonsterView.Ex.ANGRY; else -> MonsterView.Ex.CRYING }
  private fun refresh() {
    val total = Stats.total(this); val l = Stats.level(total)
    if (total != lastTotal) { if (lastTotal >= 0) v.bump(); lastChange = System.currentTimeMillis() }
    v.count = total; v.setLevelScale(scales[l - 1]); if (!shocked) v.ex = exFor(l)
    if (l != lastLevel || (total != lastTotal && total % 7 == 0)) speak(l)
    lastLevel = l; lastTotal = total; v.invalidate()
  }
  private fun speak(l: Int) {
    val pick = (pools[l]!!.filter { it != lastSpoken }.ifEmpty { pools[l]!! }).random(); lastSpoken = pick
    v.speech = pick; v.invalidate(); h.removeCallbacks(clear); h.postDelayed(clear, 4500)
  }
  private fun tap() { shocked = true; v.ex = MonsterView.Ex.SHOCKED; speak(Stats.level(Stats.total(this)))
    h.postDelayed({ shocked = false; v.ex = exFor(lastLevel) ; v.invalidate() }, 1500) }
  private fun sleepCheck() { h.postDelayed({ if (!shocked && System.currentTimeMillis() - lastChange > 90_000) { v.ex = MonsterView.Ex.SLEEPY; v.invalidate() } else if (!shocked) v.ex = exFor(lastLevel); sleepCheck() }, 10_000) }
  override fun onDestroy() { h.removeCallbacksAndMessages(null); unregisterReceiver(rec); wm.removeView(v); super.onDestroy() }
  override fun onBind(i: Intent?): IBinder? = null
}
