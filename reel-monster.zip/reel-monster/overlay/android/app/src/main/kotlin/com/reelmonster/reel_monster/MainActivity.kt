package com.reelmonster.reel_monster
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
  override fun configureFlutterEngine(fe: FlutterEngine) {
    super.configureFlutterEngine(fe)
    MethodChannel(fe.dartExecutor.binaryMessenger, "reelmonster").setMethodCallHandler { call, res ->
      when (call.method) {
        "stats" -> { val t = Stats.total(this)
          val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
          res.success(mapOf("ig" to Stats.get(this, "ig"), "yt" to Stats.get(this, "yt"), "sec" to Stats.get(this, "sec"),
            "level" to Stats.level(t), "a11y" to en.contains("$packageName/"), "overlay" to Settings.canDrawOverlays(this))) }
        "openAccessibility" -> { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); res.success(null) }
        "requestOverlay" -> { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); res.success(null) }
        "startOverlay" -> { if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, OverlayService::class.java)); res.success(null) }
        "stopOverlay" -> { stopService(Intent(this, OverlayService::class.java)); res.success(null) }
        else -> res.notImplemented()
      }
    }
  }
}
