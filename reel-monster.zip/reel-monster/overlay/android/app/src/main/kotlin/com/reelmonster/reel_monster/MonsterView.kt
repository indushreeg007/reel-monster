package com.reelmonster.reel_monster
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.text.*
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.sin

class MonsterView(ctx: Context) : View(ctx) {
  enum class Ex { HAPPY, EXCITED, SLEEPY, ANGRY, SHOCKED, CRYING, OVERWHELMED }
  var count = 0; var ex = Ex.HAPPY; var scale = 0.45f; var speech: String? = null; var minimized = false
  private val d = resources.displayMetrics.density
  private val p = Paint(Paint.ANTI_ALIAS_FLAG)
  private var t = 0f; private var pop = 1f
  private val bob = ValueAnimator.ofFloat(0f, 6.2832f).apply {
    duration = 1800; repeatCount = -1; addUpdateListener { t = it.animatedValue as Float; invalidate() }; start() }
  fun setLevelScale(s: Float) { ValueAnimator.ofFloat(scale, s).apply { duration = 600; interpolator = OvershootInterpolator()
    addUpdateListener { scale = it.animatedValue as Float; invalidate() }; start() } }
  fun bump() { ValueAnimator.ofFloat(1.3f, 1f).apply { duration = 300; addUpdateListener { pop = it.animatedValue as Float; invalidate() }; start() } }
  override fun onDetachedFromWindow() { bob.cancel(); super.onDetachedFromWindow() }
  private fun fill(c: Int) { p.style = Paint.Style.FILL; p.color = c }
  private fun line(c: Int) { p.style = Paint.Style.STROKE; p.color = c; p.strokeWidth = 3 * d; p.strokeCap = Paint.Cap.ROUND }
  fun hitsButton(x: Float, y: Float) = x > width - 30 * d && y < 30 * d

  override fun onDraw(c: Canvas) {
    val s = (if (minimized) 0.35f else scale)
    val cx = width / 2f; val r = 62 * d * s; val cy = height * 0.6f + sin(t) * 4 * d
    val dark = 0xFF2D1B4E.toInt()
    fill(0xFF9F7AEA.toInt())
    c.drawOval(cx - r * .55f, cy + r * .8f, cx - r * .15f, cy + r * 1.15f, p); c.drawOval(cx + r * .15f, cy + r * .8f, cx + r * .55f, cy + r * 1.15f, p)
    c.drawCircle(cx - r * 1.05f, cy + r * .2f, r * .2f, p); c.drawCircle(cx + r * 1.05f, cy + r * .2f, r * .2f, p)
    fill(0xFFF9A8D4.toInt())
    for (sgn in listOf(-1f, 1f)) { val h = Path(); h.moveTo(cx + sgn * r * .7f, cy - r * .65f); h.lineTo(cx + sgn * r * .5f, cy - r * 1.2f); h.lineTo(cx + sgn * r * .2f, cy - r * .9f); c.drawPath(h, p) }
    fill(0xFFB794F4.toInt()); c.drawCircle(cx, cy, r, p)
    fill(0xFFE9D8FD.toInt()); c.drawOval(cx - r * .5f, cy + r * .15f, cx + r * .5f, cy + r * .85f, p)
    val ey = cy - r * .15f; val dx = r * .35f; val er = r * .22f * (if (ex == Ex.SHOCKED) 1.3f else 1f)
    for (sgn in listOf(-1f, 1f)) {
      val ex0 = cx + sgn * dx
      if (ex == Ex.SLEEPY) { line(dark); c.drawArc(ex0 - er, ey - er, ex0 + er, ey + er, 0f, 180f, false, p) }
      else { fill(Color.WHITE); c.drawCircle(ex0, ey, er, p); fill(dark); c.drawCircle(ex0, ey, er * (if (ex == Ex.EXCITED) .75f else if (ex == Ex.OVERWHELMED) .3f else .5f), p) }
      if (ex == Ex.ANGRY) { line(dark); c.drawLine(ex0 - sgn * er * 1.2f, ey - er * 1.6f, ex0 + sgn * er * 1.2f, ey - er * .8f, p).also { } }
      if (ex == Ex.CRYING) { fill(0xFF63B3ED.toInt()); val ty = ey + er * 1.2f + (t % 3f) * 4 * d; c.drawOval(ex0 - er * .3f, ty, ex0 + er * .3f, ty + er * .9f, p) }
    }
    if (ex == Ex.OVERWHELMED) { fill(0xFF63B3ED.toInt()); c.drawOval(cx - r * .08f, cy - r * .85f, cx + r * .08f, cy - r * .6f, p) }
    val my = cy + r * .35f; val mw = r * .3f
    when (ex) {
      Ex.HAPPY -> { line(dark); c.drawArc(cx - mw, my - mw, cx + mw, my + mw, 20f, 140f, false, p) }
      Ex.EXCITED -> { fill(dark); c.drawOval(cx - mw, my - mw * .3f, cx + mw, my + mw * 1.1f, p) }
      Ex.SLEEPY -> { fill(dark); c.drawOval(cx - mw * .3f, my, cx + mw * .3f, my + mw * .5f, p) }
      Ex.SHOCKED -> { fill(dark); c.drawCircle(cx, my + mw * .3f, mw * .5f, p) }
      Ex.ANGRY, Ex.CRYING -> { line(dark); c.drawArc(cx - mw, my, cx + mw, my + mw * 1.6f, 200f, 140f, false, p) }
      Ex.OVERWHELMED -> { line(dark); val z = Path(); z.moveTo(cx - mw, my + mw * .3f); for (i in 1..4) z.lineTo(cx - mw + i * mw / 2f, my + if (i % 2 == 1) 0f else mw * .5f); c.drawPath(z, p) }
    }
    // counter bubble
    val label = if (minimized) "$count" else "$count REELS"
    p.textSize = 13 * d * (if (minimized) 1f else pop); p.typeface = Typeface.DEFAULT_BOLD
    val tw = p.measureText(label); val by = maxOf(cy - r * 1.3f - 30 * d, 6 * d)
    fill(Color.WHITE); c.drawRoundRect(cx - tw / 2 - 10 * d, by, cx + tw / 2 + 10 * d, by + 26 * d, 14 * d, 14 * d, p)
    fill(0xFF6B46C1.toInt()); c.drawText(label, cx - tw / 2, by + 18 * d, p)
    // minimize button
    fill(0xFFFBCFE8.toInt()); c.drawCircle(width - 14 * d, 14 * d, 11 * d, p)
    fill(dark); p.textSize = 14 * d; c.drawText(if (minimized) "+" else "–", width - 14 * d - p.measureText(if (minimized) "+" else "–") / 2, 19 * d, p)
    // speech
    speech?.takeIf { !minimized }?.let {
      val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = dark; textSize = 11 * d; typeface = Typeface.DEFAULT_BOLD }
      val sl = StaticLayout.Builder.obtain(it, 0, it.length, tp, (176 * d).toInt()).setAlignment(Layout.Alignment.ALIGN_CENTER).build()
      val top = height - sl.height - 16 * d
      fill(0xFFFFF7ED.toInt()); c.drawRoundRect(6 * d, top - 6 * d, width - 6 * d, height - 4 * d, 14 * d, 14 * d, p)
      c.save(); c.translate(12 * d, top); sl.draw(c); c.restore()
    }
  }
}
