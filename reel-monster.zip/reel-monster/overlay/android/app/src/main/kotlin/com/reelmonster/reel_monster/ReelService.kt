package com.reelmonster.reel_monster
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Detection is heuristic. IDs below are CONFIGURABLE and WILL break when Instagram/YouTube change their UI. */
class ReelService : AccessibilityService() {
  data class Cfg(val pkg: String, val key: String, val feed: List<String>, val blockers: List<String>)
  private val cfgs = listOf(
    Cfg("com.instagram.android", "ig",
      listOf("com.instagram.android:id/clips_viewer_view_pager", "com.instagram.android:id/clips_swipe_refresh_container"),
      listOf("com.instagram.android:id/layout_comment_thread_container", "com.instagram.android:id/action_sheet_container")),
    Cfg("com.google.android.youtube", "yt",
      listOf("com.google.android.youtube:id/reel_recycler", "com.google.android.youtube:id/reel_player_page_container"),
      listOf("com.google.android.youtube:id/engagement_panel_container", "com.google.android.youtube:id/bottom_sheet")))
  private val idHint = Regex("username|author|caption|channel|title|description", RegexOption.IGNORE_CASE)
  private var lastSig: String? = null; private var lastCount = 0L; private var lastTs = 0L

  override fun onAccessibilityEvent(e: AccessibilityEvent) {
    val cfg = cfgs.firstOrNull { it.pkg == e.packageName?.toString() } ?: run { lastSig = null; lastTs = 0; return }
    val root = rootInActiveWindow ?: return
    if (cfg.feed.none { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() }) { lastSig = null; lastTs = 0; return }
    if (cfg.blockers.any { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() }) return // comments/share/sheets
    val now = System.currentTimeMillis()
    if (lastTs > 0) Stats.add(this, "sec", minOf(now - lastTs, 5000L) / 1000)
    lastTs = now
    val sig = signature(root)
    val count = if (sig.isNotEmpty()) sig != lastSig && now - lastCount > 600
                else e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED && now - lastCount > 900 // fallback: less accurate
    if (sig.isNotEmpty()) lastSig = sig
    if (count) {
      lastCount = now
      Stats.add(this, cfg.key, 1)
      sendBroadcast(Intent("com.reelmonster.UPDATE").setPackage(packageName))
    }
  }

  private fun signature(n: AccessibilityNodeInfo?): String {
    val sb = StringBuilder()
    fun walk(x: AccessibilityNodeInfo?, depth: Int) {
      if (x == null || depth > 25 || sb.length > 300) return
      val id = x.viewIdResourceName ?: ""
      if (x.isVisibleToUser && idHint.containsMatchIn(id)) (x.text ?: x.contentDescription)?.let { sb.append(it).append('|') }
      for (i in 0 until x.childCount) walk(x.getChild(i), depth + 1)
    }
    walk(n, 0); return sb.toString()
  }
  override fun onInterrupt() {}
}
