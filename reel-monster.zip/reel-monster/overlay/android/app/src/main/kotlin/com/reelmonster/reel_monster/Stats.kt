package com.reelmonster.reel_monster
import android.content.Context
import java.text.SimpleDateFormat
import java.util.*
object Stats {
  private fun p(c: Context) = c.getSharedPreferences("rm", 0)
  private fun d() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
  fun get(c: Context, k: String) = p(c).getLong("${d()}_$k", 0)
  fun add(c: Context, k: String, n: Long) { p(c).edit().putLong("${d()}_$k", get(c, k) + n).apply() }
  fun total(c: Context) = (get(c, "ig") + get(c, "yt")).toInt()
  fun level(t: Int) = when { t <= 10 -> 1; t <= 30 -> 2; t <= 60 -> 3; t <= 100 -> 4; t <= 150 -> 5; else -> 6 }
}
